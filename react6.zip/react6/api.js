export const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export async function mockFetchUser(userId, { shouldFail = false, delayMs = 500 } = {}) {
  await delay(delayMs);
  if (shouldFail) {
    throw new Error(`[500 Server Error] Не удалось загрузить пользователя ID: ${userId}`);
  }
  return {
    id: userId,
    name: `Пользователь #${userId}`,
    role: userId === "u1" ? "admin" : "developer",
    loadedAt: new Date().toLocaleTimeString()
  };
}

export default mockFetchUser;
