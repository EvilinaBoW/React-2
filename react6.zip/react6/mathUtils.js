export const validateMinLength = (minLength) => (value) => 
  value.length >= minLength
    ? { valid: true }
    : { valid: false, error: `Минимальная длина должна быть ${minLength} символов` };

export const validateRange = (min, max) => (value) => 
  value >= min && value <= max
    ? { valid: true }
    : { valid: false, error: `Число должно быть в диапазоне от ${min} до ${max}` };

export const isPasswordSecure = validateMinLength(8);
export const isAgeValid = validateRange(18, 65);
