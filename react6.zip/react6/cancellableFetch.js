import { mockFetchUser } from "./api.js";
import { isPasswordSecure, isAgeValid } from "./mathUtils.js";
import { fetchDataWithCancel } from "./cancellableFetch.js";

console.log(isPasswordSecure("secret123"));
console.log(isAgeValid(25));

async function loadDashboardWidgets() {
  const userIds = ["u1", "u2_failed", "u3"];
  const requests = userIds.map((id) => mockFetchUser(id, { shouldFail: id.includes("failed") }));
  const results = await Promise.allSettled(requests);

  const successfulUsers = [];
  const failedErrors = [];

  results.forEach((result, index) => {
    if (result.status === "fulfilled") {
      successfulUsers.push(result.value);
    } else {
      failedErrors.push({ id: userIds[index], reason: result.reason.message });
    }
  });

  console.log("Успешно:", successfulUsers);
  console.log("Ошибки:", failedErrors);
}

await loadDashboardWidgets();

async function runCancellableScenario() {
  const controller = new AbortController();
  const fetchPromise = fetchDataWithCancel("https://example.com", { signal: controller.signal });

  setTimeout(() => controller.abort(), 300);

  try {
    const response = await fetchPromise;
    console.log(response);
  } catch (error) {
    if (error.name === "AbortError") {
      console.log("Отменено:", error.message);
    } else {
      console.error(error);
    }
  }
}

await runCancellableScenario();
