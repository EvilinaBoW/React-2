/**
 * ============================================================================
 * РАЗДЕЛ 3: ПАМЯТЬ, ПЕРЕМЕННЫЕ, ОБЛАСТИ ВИДИМОСТИ И ЗАМЫКАНИЯ
 * ============================================================================
 */

/**
 * ЗАДАЧА 11: Рекурсивный Deep Freeze
 * Рекурсивно обходит вложенные свойства объекта и блокирует их модификацию через Object.freeze.
 */
function deepFreeze(obj) {
  // Получаем все свойства объекта (включая неперечисляемые, если нужно, но Object.getOwnPropertyNames надежнее)
  const propNames = Object.getOwnPropertyNames(obj);

  // Замораживаем свойства перед заморозкой самого объекта
  for (const name of propNames) {
    const value = obj[name];

    if (value && (typeof value === 'object' || typeof value === 'function') && !Object.isFrozen(value)) {
      deepFreeze(value);
    }
  }

  return Object.freeze(obj);
}


/**
 * ЗАДАЧА 12: Фабрика счетчиков с изолированным состоянием (Замыкания)
 * Инкапсулирует переменную состояния внутри лексического окружения функции.
 */
function createCounter(initialValue = 0, step = 1) {
  let count = initialValue; // Приватная переменная, недоступная извне

  return {
    inc() {
      count += step;
      return count;
    },
    dec() {
      count -= step;
      return count;
    },
    reset() {
      count = initialValue;
      return count;
    },
    get() {
      return count;
    }
  };
}


/**
 * ЗАДАЧА 13: Универсальный мемоизатор (Memoize Function)
 * Кэширует результаты чистой функции на основе сериализованных аргументов.
 */
function memoize(fn) {
  const cache = new Map();

  return function (...args) {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      console.log('[Cache Hit]: Возвращаем сохраненное значение');
      return cache.get(key);
    }

    console.log('[Cache Miss]: Вычисляем новое значение');
    const result = fn(...args);
    cache.set(key, result);
    return result;
  };
}


/**
 * ЗАДАЧА 14: Каррированная фабрика валидаторов инпута
 * Возвращает функцию-валидатор на основе правила и параметра.
 */
function createValidator(ruleName, param) {
  const rules = {
    minLength: (val, min) => typeof val === 'string' && val.length >= min,
    maxLength: (val, max) => typeof val === 'string' && val.length <= max,
    pattern: (val, regex) => regex instanceof RegExp && regex.test(val)
  };

  return function (value) {
    const validatorFn = rules[ruleName];
    if (!validatorFn) {
      return { isValid: false, message: `Неизвестное правило валидации: ${ruleName}` };
    }

    const isValid = validatorFn(value, param);
    return {
      isValid,
      message: isValid ? 'Валидация успешна' : `Ошибка проверки правила "${ruleName}" с параметром ${param}`
    };
  };
}


/**
 * ЗАДАЧА 15: Безопасный экстрактор данных с fallback-значением
 * Безопасно извлекает вложенное свойство объекта, используя Optional Chaining и Nullish Coalescing.
 */
function getNestedValue(data, fallback = null) {
  try {
    // Безопасный доступ через опциональную цепочку с поддержкой оператора ??
    return data?.payload?.user?.settings?.theme ?? fallback;
  } catch {
    return fallback;
  }
}