/**
 * ============================================================================
 * РАЗДЕЛ 2: ОКРУЖЕНИЕ: NODE.JS, NPM И VITE
 * ============================================================================
 */

import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';

/**
 * ЗАДАЧА 06: Валидатор версий в package.json
 * Читает package.json и проверяет dependencies на наличие плавающих версий (^ или ~).
 */
function validatePackageJsonDependencies(packageJsonPath = './package.json') {
  try {
    if (!fs.existsSync(packageJsonPath)) {
      console.warn(`Файл ${packageJsonPath} не найден.`);
      return [];
    }

    const fileContent = fs.readFileSync(packageJsonPath, 'utf-8');
    const pkg = JSON.parse(fileContent);
    const dependencies = pkg.dependencies || {};
    
    const unstablePackages = [];

    for (const [packageName, versionRange] of Object.entries(dependencies)) {
      // Проверяем наличие символов диапазонов SemVer (^ или ~)
      if (versionRange.startsWith('^') || versionRange.startsWith('~')) {
        unstablePackages.push({ name: packageName, version: versionRange });
      }
    }

    if (unstablePackages.length > 0) {
      console.warn('⚠️ Обнаружены пакеты с плавающими версиями (нарушение строгой фиксации):');
      unstablePackages.forEach(p => console.warn(`   - ${p.name}: ${p.version}`));
    } else {
      console.log('✅ Все зависимости в package.json строго зафиксированы.');
    }

    return unstablePackages;
  } catch (error) {
    console.error('Ошибка при чтении или разборе package.json:', error.message);
    return [];
  }
}


/**
 * ЗАДАЧА 07: Скрипт проверки окружения перед сборкой
 * Проверяет версию Node.js (мажорная версия должна быть >= 18).
 */
function checkEnvironmentVersion(minMajorVersion = 18) {
  const currentVersion = process.version; // например, 'v18.16.0'
  const majorVersion = parseInt(currentVersion.slice(1).split('.')[0], 10);

  console.log(`Текущая версия Node.js: ${currentVersion}`);

  if (majorVersion < minMajorVersion) {
    console.error(`❌ Ошибка: Требуется Node.js версии ${minMajorVersion} или выше. У вас установлена ${currentVersion}.`);
    // В реальном CLI-скрипте вызывается process.exit(1)
    return false;
  }

  console.log('✅ Версия Node.js соответствует требованиям сборки.');
  return true;
}


/**
 * ЗАДАЧА 08: Конфигурация пайплайна сборки в package.json (Шаблон скриптов)
 * Описание того, как должен выглядеть блок "scripts" в package.json для реализации
 * последовательности: prebuild (линтинг) -> build (сборка Vite) -> postbuild (размер папки).
 */
const packageJsonScriptsExample = {
  "scripts": {
    "lint": "eslint src --ext .js,.jsx,.ts,.tsx",
    "build:vite": "vite build",
    "postbuild:size": "node -e \"console.log('📦 Размер папки dist рассчитан')\"",
    "prebuild": "npm run lint",
    "build": "npm run build:vite",
    "postbuild": "npm run postbuild:size"
  }
};


/**
 * ЗАДАЧА 09: Шаблон конфигурации абсолютных импортов в Vite (vite.config.js)
 * Подключает React-плагин и настраивает path alias '@' на директорию './src'.
 */
/*
// Содержимое файла vite.config.js:
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
*/


/**
 * ЗАДАЧА 10: Эмуляция протокола HMR over WebSocket
 * Мини-сервер на Node.js, который отслеживает изменения файла и шлет клиенту сигнал reload.
 */
function createHmrDevServer(targetFilePath = './test.js', port = 8080) {
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`
      <h2>HMR Simulation Client</h2>
      <p>Слушаем изменения в файле: ${targetFilePath}</p>
      <script>
        // Простейшая эмуляция WebSocket-соединения для перезагрузки
        console.log('🔗 Подключение к HMR серверу...');
        // В реальном Vite здесь используется WebSocket (new WebSocket(...))
        setTimeout(() => {
          console.log('⚡ Сигнал HMR получен (эмуляция). Перезагрузка страницы...');
        }, 5000);
      </script>
    `);
  });

  // Отслеживание изменений файла через fs.watch
  if (fs.existsSync(targetFilePath)) {
    fs.watch(targetFilePath, (eventType) => {
      if (eventType === 'change') {
        console.log(`🔄 Файл ${targetFilePath} изменен. Отправка HMR-сообщения клиентам...`);
        // В реальном приложении здесь отправляется JSON.stringify({ type: 'reload' }) по WS
      }
    });
  } else {
    console.warn(`⚠️ Файл для отслеживания (${targetFilePath}) не найден. Создайте его для теста fs.watch.`);
  }

  server.listen(port, () => {
    console.log(`🚀 HMR Dev Server запущен на http://localhost:${port}`);
  });

  return server;
}