/**
 * ============================================================================
 * РАЗДЕЛ 6: ФУНКЦИИ, МОДУЛИ, PROMISES И ASYNC/AWAIT
 * ============================================================================
 */

/**
 * ЗАДАЧА 26: Промисификация функции задержки (delay / wait)
 * Возвращает Promise, который успешно завершается через указанный интервал времени.
 */
function wait(milliseconds) {
  return new Promise((resolve) => {
    setTimeout(resolve, milliseconds);
  });
}


/**
 * ЗАДАЧА 27: Отказоустойчивый дашборд (Promise.allSettled)
 * Параллельно выполняет несколько запросов и возвращает объект с успешными данными и ошибками,
 * не прерывая работу интерфейса при сбое отдельных частей.
 */
async function loadDashboard(asyncTasks = []) {
  const results = await Promise.allSettled(asyncTasks);

  const successData = [];
  const errors = [];

  results.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      successData.push(result.value);
    } else {
      errors.push({
        index,
        reason: result.reason?.message || String(result.reason)
      });
    }
  });

  return { successData, errors };
}


/**
 * ЗАДАЧА 28: Отмена устаревших запросов (AbortController)
 * Прерывает сетевой вызов fetch и выбрасывает ошибку при превышении тайм-аута.
 */
async function fetchWithTimeout(url, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error(`Запрос к ${url} был прерван по тайм-ауту (${timeoutMs}ms)`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}


/**
 * ЗАДАЧА 29: Утилита автоматических повторов (Retry Pattern)
 * Повторяет вызов нестабильной асинхронной функции заданное количество раз с задержкой.
 */
async function retry(asyncFn, retries = 3, delayMs = 500) {
  try {
    return await asyncFn();
  } catch (error) {
    if (retries <= 0) {
      throw error;
    }
    console.warn(`⚠️ Ошибка выполнения. Осталось попыток: ${retries}. Повтор через ${delayMs}ms...`);
    await wait(delayMs);
    // Рекурсивный вызов с уменьшением количества попыток (экспоненциальный рост задержки опционально)
    return retry(asyncFn, retries - 1, delayMs * 1.5);
  }
}


/**
 * ЗАДАЧА 30: Последовательная асинхронная очередь (Async Queue Runner)
 * Гарантирует, что добавленные задачи выполняются строго по очереди (Concurrency = 1).
 */
class AsyncQueue {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
  }

  enqueue(taskFn) {
    return new Promise((resolve, reject) => {
      this.queue.push(async () => {
        try {
          const result = await taskFn();
          resolve(result);
        } catch (error) {
          reject(error);
        }
      });

      this.process();
    });
  }

  async process() {
    if (this.isProcessing || this.queue.length === 0) {
      return;
    }

    this.isProcessing = true;
    const currentTask = this.queue.shift();

    try {
      await currentTask();
    } finally {
      this.isProcessing = false;
      this.process(); // Переходим к следующей задаче в очереди
    }
  }
}