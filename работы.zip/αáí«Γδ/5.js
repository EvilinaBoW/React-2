/**
 * ============================================================================
 * РАЗДЕЛ 5: ОБЪЕКТЫ, ДЕСТРУКТУРИЗАЦИЯ, SPREAD И REST
 * ============================================================================
 */

/**
 * ЗАДАЧА 21: Трехуровневое иммутабельное обновление стейта
 * Обновляет поле state.user.profile.notifications.email на противоположное булево значение,
 * сохраняя ссылочную неизменность нетронутых веток (например, state.posts).
 */
function toggleEmailNotification(state) {
  return {
    ...state,
    user: {
      ...state.user,
      profile: {
        ...state.user.profile,
        notifications: {
          ...state.user.profile.notifications,
          email: !state.user.profile.notifications.email
        }
      }
    }
    // Сетка state.posts сохраняет свою старую ссылку в памяти, так как не затронута
  };
}


/**
 * ЗАДАЧА 22: Исключение кастомных пропсов (Omit Props)
 * Очищает объект свойств, удаляя кастомные атрибуты фреймворка через rest-деструктуризацию.
 */
function extractDomProps(allProps, customKeysArray = ['primary', 'rounded', 'loading']) {
  const domProps = { ...allProps };

  for (const key of customKeysArray) {
    delete domProps[key];
  }

  return domProps;
}


/**
 * ЗАДАЧА 23: Рекурсивный Deep Merge конфигураций
 * Объединяет два объекта произвольной вложенности так, чтобы вложенные объекты сливались, а не перезаписывались целиком.
 */
function deepMerge(target, source) {
  const output = { ...target };

  if (!source || typeof source !== 'object') {
    return output;
  }

  for (const key of Object.keys(source)) {
    const targetValue = target[key];
    const sourceValue = source[key];

    if (
      targetValue &&
      sourceValue &&
      typeof targetValue === 'object' &&
      typeof sourceValue === 'object' &&
      !Array.isArray(targetValue) &&
      !Array.isArray(sourceValue)
    ) {
      output[key] = deepMerge(targetValue, sourceValue);
    } else {
      output[key] = sourceValue;
    }
  }

  return output;
}


/**
 * ЗАДАЧА 24: Нормализатор реляционных сущностей (byId & allIds) и точечный патчер за O(1)
 */
function normalizeEntities(array) {
  return {
    byId: Object.fromEntries(array.map(item => [item.id, { ...item }])),
    allIds: array.map(item => item.id)
  };
}

function patchEntityById(state, id, patch) {
  const currentEntity = state.byId[id];
  if (!currentEntity) return state;

  return {
    ...state,
    byId: {
      ...state.byId,
      [id]: {
        ...currentEntity,
        ...patch,
        updatedAt: Date.now()
      }
    }
    // allIds сохраняет старую ссылку, порядок элементов не изменился
  };
}


/**
 * ЗАДАЧА 25: Универсальный обработчик формы с вычисляемыми ключами
 * Динамически обновляет поле формы с использованием Computed Property Names ([fieldName]: fieldValue).
 */
function updateFormState(prevState, fieldName, fieldValue) {
  return {
    ...prevState,
    [fieldName]: fieldValue,
    isDirty: true
  };
}