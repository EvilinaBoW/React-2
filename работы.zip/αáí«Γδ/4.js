/**
 * ============================================================================
 * РАЗДЕЛ 4: МАССИВЫ И МЕТОДЫ MAP, FILTER, FIND, REDUCE
 * ============================================================================
 */

/**
 * ЗАДАЧА 16: Форматирование витрины товаров (.map)
 * Добавляет отформатированную цену (с разделителями тысяч) и флаг доступности для заказа.
 */
function formatProductsCatalog(products) {
  return products.map(product => {
    // Форматируем цену в виде "2 500 ₽"
    const formattedPrice = new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      maximumFractionDigits: 0
    }).format(product.price);

    return {
      ...product,
      displayPrice: formattedPrice,
      isOrderable: product.inStock && product.price > 0
    };
  });
}


/**
 * ЗАДАЧА 17: Комбинированный фильтр каталога (.filter)
 * Фильтрует массив товаров по динамическому объекту критериев.
 */
function filterCatalog(items, criteria = {}) {
  const { category, maxPrice, onlyInStock } = criteria;

  return items.filter(item => {
    // Фильтрация по категории (если задана)
    if (category && item.category !== category) {
      return false;
    }

    // Фильтрация по максимальной цене (если задана)
    if (maxPrice !== undefined && item.price > maxPrice) {
      return false;
    }

    // Фильтрация по наличию (если true)
    if (onlyInStock === true && !item.inStock) {
      return false;
    }

    return true;
  });
}


/**
 * ЗАДАЧА 18: Переключение флага в массиве объектов (.map)
 * Возвращает новый массив, инвертируя флаг done у задачи с указанным ID.
 */
function toggleTodoStatus(todos, todoId) {
  return todos.map(todo => {
    if (todo.id === todoId) {
      return { ...todo, done: !todo.done };
    }
    // Сохраняем ссылку на нетронутые элементы (структурная изоляция)
    return todo;
  });
}


/**
 * ЗАДАЧА 19: Группировка списка по категориям (.reduce)
 * Сворачивает массив товаров в объект вида { [categoryName]: Product[] }.
 */
function groupProductsByCategory(items) {
  return items.reduce((acc, item) => {
    const category = item.category || 'uncategorized';

    if (!acc[category]) {
      acc[category] = [];
    }

    acc[category].push(item);
    return acc;
  }, {});
}


/**
 * ЗАДАЧА 20: Дедупликация массива объектов по ключу
 * Удаляет дубликаты объектов по указанному ключу, сохраняя первое найденное вхождение.
 */
function uniqueBy(array, key) {
  const seen = new Set();

  return array.filter(item => {
    const keyValue = item[key];
    if (seen.has(keyValue)) {
      return false;
    }
    seen.add(keyValue);
    return true;
  });
}