/**
 * ============================================================================
 * РАЗДЕЛ 1: АРХИТЕКТУРА SPA И ОСНОВЫ REACT
 * ============================================================================
 */

/**
 * ЗАДАЧА 01: Клиентский роутер на History API
 * Перехватывает клики по ссылкам <a>, управляет историей браузера и эмулирует SPA-навигацию.
 */
class ClientRouter {
  constructor(routes = {}) {
    this.routes = routes;
    this.initListeners();
  }

  initListeners() {
    // Перехват кликов по тегам <a> для предотвращения полной перезагрузки страницы
    document.addEventListener('click', (event) => {
      const anchor = event.target.closest('a');
      if (!anchor) return;

      const href = anchor.getAttribute('href');
      // Проверяем, что ссылка является внутренней (начинается с '/')
      if (href && href.startsWith('/')) {
        event.preventDefault();
        this.navigate(href);
      }
    });

    // Обработка кнопок "Назад" / "Вперед" в браузере
    window.addEventListener('popstate', () => {
      this.handleRoute(window.location.pathname);
    });
  }

  navigate(path) {
    window.history.pushState({}, '', path);
    this.handleRoute(path);
  }

  handleRoute(path) {
    const routeHandler = this.routes[path] || this.routes['*'];
    if (routeHandler) {
      const content = routeHandler();
      // Рендерим контент в корневой элемент приложения (например, с id="app")
      const appContainer = document.getElementById('app');
      if (appContainer) {
        appContainer.innerHTML = content;
      }
    }
  }

  // Первоначальный запуск роутера при загрузке страницы
  init() {
    this.handleRoute(window.location.pathname);
  }
}


/**
 * ЗАДАЧА 02: Эмуляция функции React.createElement (createVNode)
 * Формирует виртуальный узел, корректно обрабатывая текстовые дочерние элементы.
 */
function createVNode(type, props = {}, ...children) {
  // Уплотняем массив детей и очищаем от пустоты
  const flatChildren = children.flat().filter(child => child != null);

  return {
    type,
    props: {
      ...props,
      // Если дочерний элемент один и это примитив (строка/число), оставляем его как есть
      children: flatChildren.length === 1 && (typeof flatChildren[0] === 'string' || typeof flatChildren[0] === 'number')
        ? flatChildren[0]
        : flatChildren
    },
    key: props.key || null
  };
}


/**
 * ЗАДАЧА 03: Алгоритм поверхностного сравнения (shallowEqual)
 * Определяет, изменились ли пропсы компонента на первом уровне вложенности.
 */
function shallowEqual(objA, objB) {
  if (Object.is(objA, objB)) return true;

  if (typeof objA !== 'object' || objA === null || typeof objB !== 'object' || objB === null) {
    return false;
  }

  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);

  if (keysA.length !== keysB.length) return false;

  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!Object.prototype.hasOwnProperty.call(objB, key) || !Object.is(objA[key], objB[key])) {
      return false;
    }
  }

  return true;
}


/**
 * ЗАДАЧА 04: Поднятие состояния (Lifting State Up)
 * Моделирует однонаправленный поток данных: Child не мутирует стейт напрямую, а вызывает callback Parent.
 */
class StateManagerSimulation {
  constructor(initialCount = 0) {
    this.count = initialCount;
  }

  // Родительский компонент (хранит состояние)
  Parent() {
    return {
      count: this.count,
      // Callback, передаваемый дочернему компоненту для изменения состояния
      handleIncrement: () => {
        this.count += 1;
        console.log(`[Parent State Updated]: count = ${this.count}`);
      }
    };
  }

  // Дочерний компонент (принимает пропсы и вызывает callback)
  Child(props) {
    return {
      render: () => `<div>Count: ${props.count}</div>`,
      triggerAction: () => {
        // Дочерний компонент НЕ имеет права писать в state напрямую (this.count++ запрещен),
        // он обязан вызвать переданную функцию родителя:
        props.onIncrement();
      }
    };
  }
}


/**
 * ЗАДАЧА 05: Рендерер виртуального дерева в строку (SSR Engine)
 * Рекурсивно превращает Virtual DOM в HTML-строку, трансформируя className в class.
 */
function renderToHTML(vNode) {
  // Обработка текстовых/числовых нод
  if (typeof vNode === 'string' || typeof vNode === 'number') {
    return String(vNode);
  }

  if (!vNode || typeof vNode.type !== 'string') {
    return '';
  }

  const { type, props } = vNode;
  const attributes = [];

  for (const [key, value] of Object.entries(props)) {
    if (key === 'children') continue;

    // Требование: преобразование className в class
    const attrName = key === 'className' ? 'class' : key;

    if (value === true) {
      attributes.push(` ${attrName}`);
    } else if (value !== false && value != null) {
      attributes.push(` ${attrName}="${String(value).replace(/"/g, '&quot;')}"`);
    }
  }

  // Обработка дочерних элементов (рекурсия)
  const childrenArray = Array.isArray(props.children) ? props.children : [props.children];
  const childrenHTML = childrenArray.map(child => renderToHTML(child)).join('');

  // Поддержка самозакрывающихся тегов
  const selfClosingTags = ['img', 'input', 'br', 'hr', 'meta', 'link'];
  if (selfClosingTags.includes(type.toLowerCase()) && !childrenHTML) {
    return `<${type}${attributes.join('')} />`;
  }

  return `<${type}${attributes.join('')}>${childrenHTML}</${type}>`;
}